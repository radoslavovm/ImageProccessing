public class TestImageImpl {

}
