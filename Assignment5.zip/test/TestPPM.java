import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import model.fileUtils.FileType;
import model.fileUtils.PPM;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;
import org.junit.Test;

/**
 * Serves as the test class for the PPM class.
 */
public class TestPPM {
  FileType<Image> ppm;

  /**
   * Initializes data for the purpose of testing.
   */
  public void initData() {
    ppm = new PPM();
  }

  //tests that the read method produces an image object
  @Test
  public void testRead_PPM() {
    initData();
    Image resultant = ppm.read("./Koala.ppm");
    assertTrue(resultant instanceof Image);
  }
}
