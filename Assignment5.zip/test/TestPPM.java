public class TestPPM {
  //demo main
  public static void main(String []args) {
    String filename;

    if (args.length>0) {
      filename = args[0];
    }
    else {
      filename = "sample.ppm";
    }

    ImageUtil.readPPM(filename);
  }
}
