import java.util.ArrayList;
import java.util.Arrays;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.fileUtils.FileType;
import model.fileUtils.PPM;
import model.filters.FilterCommand;
import model.filters.GaussianBlur;
import model.filters.Grayscale;
import model.filters.Sepia;
import model.filters.Sharpen;
import model.image.ColorImpl;
import model.image.Image;
import model.programmatics.CheckerBoard;
import model.programmatics.Programmatic;

public class main {
  //demo main
  public static void main(String []args) {
    String filename;

    if (args.length>0) {
      filename = args[0];
    }
    else {
      filename = "./res/blackbuck.ascii.ppm";
    }
    FileType<Image> ppm = new PPM();
    FilterCommand gray = new Grayscale();
    FilterCommand sepia = new Sepia();
    FilterCommand gaussianBlur = new GaussianBlur();
    FilterCommand sharpen = new Sharpen();
    Programmatic checker = new CheckerBoard(10, 10, new ColorImpl(0, 0, 0), new ColorImpl(255,255,255));
    ProcessingModel spm = new SimpleProcessingModel(null, new ArrayList<Programmatic>(
        Arrays.asList(checker)), new ArrayList<FilterCommand>(Arrays.asList(gray,sepia,gaussianBlur,sharpen)));
    spm.load(ppm, filename);
    for (int i = 0; i < spm.getNumFilterCommands(); i++) {
      spm.applyFilter(spm.getFilterAt(i));
    }
    spm.save(ppm);


    spm.load(ppm, "./res/colors.ascii.ppm");
    for (int i = 0; i < spm.getNumFilterCommands(); i++) {
      spm.applyFilter(spm.getFilterAt(i));
    }

    spm.save(ppm);

    spm.generate(20, 50, 0);
    spm.save(ppm);
  }
}
