
import static org.junit.Assert.assertEquals;

import model.image.ColorImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import org.junit.Test;

/**
 * Tests the Pixel Implementation.
 */
public class TestPixelImpl {
  Pixel pixel;

  /**
   * Initializes data for the purpose of testing the Pixel class.
   */
  public void initData() {
    pixel = new PixelImpl(new ColorImpl(12, 123, 223), new PosnImpl(100, 1000));
  }


  @Test
  public void testOutputVeracity_GetColor() {
    initData();
    assertEquals(12, pixel.getColor().getRed());
    assertEquals(123, pixel.getColor().getGreen());
    assertEquals(223, pixel.getColor().getBlue());
  }

  @Test
  public void testOutputVeracity_GetPosn() {
    initData();
    assertEquals(100, pixel.getPosn().getXPos());
    assertEquals(1000, pixel.getPosn().getYPos());
  }
}
