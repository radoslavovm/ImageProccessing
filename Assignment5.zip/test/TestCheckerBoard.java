public class TestCheckerBoard {

}
