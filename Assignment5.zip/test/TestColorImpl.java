import static org.junit.Assert.assertEquals;

import model.image.Color;
import model.image.ColorImpl;
import org.junit.Test;

/**
 * Test class for the Color Implementation
 */
public class TestColorImpl {
  Color c1;
  Color c2;
  Color c3;
  Color c4;
  Color c5;
  /**
   * Initializes the data for the test methods.
   */
  void initData() {
    c1 = new ColorImpl(0, 0, 0);
    c2 = new ColorImpl(-1, -1, -1);
    c3 = new ColorImpl(256, 256, 256);
    c4 = new ColorImpl(122, 123, 124);
    c5 = new ColorImpl(32, 103, 233);
  }

  //tests the clamp method
  @Test
  public void testClamp_Color() {
    assertEquals(122, Color.clamp(122));
    assertEquals(0, Color.clamp(-1));
    assertEquals(255, Color.clamp(25498));
  }

  //tests the getRed method, also tests the constructors assignments
  @Test
  public void testGetRedAndAssignment_ColorImpl() {
    initData();
    assertEquals(0, c1.getRed());
    assertEquals(0, c2.getRed());
    assertEquals(255, c3.getRed());
    assertEquals(122, c4.getRed());
    assertEquals(32, c5.getRed());
  }

  //tests the getGreen method, also tests the constructors assignments
  @Test
  public void testGetGreenAndAssignment_ColorImpl() {
    initData();
    assertEquals(0, c1.getGreen());
    assertEquals(0, c2.getGreen());
    assertEquals(255, c3.getGreen());
    assertEquals(123, c4.getGreen());
    assertEquals(103, c5.getGreen());
  }

  //tests the getBlue method, also tests the constructors assignments
  @Test
  public void testGetBlueAndAssignment_ColorImpl() {
    initData();
    assertEquals(0, c1.getBlue());
    assertEquals(0, c2.getBlue());
    assertEquals(255, c3.getBlue());
    assertEquals(124, c4.getBlue());
    assertEquals(233, c5.getBlue());
  }
}
