public class TestColorImpl {

}
