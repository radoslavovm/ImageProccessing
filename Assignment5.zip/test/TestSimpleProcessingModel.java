public class TestSimpleProcessingModel {

}
