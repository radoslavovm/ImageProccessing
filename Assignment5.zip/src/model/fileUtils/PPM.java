package model.fileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;

public class PPM implements FileType<Image> {

  @Override
  public Image read(String filename) {
    //create a scanner
    Scanner sc;

    try {
      //try scanning the file
      sc = new Scanner(new FileInputStream(filename));
    }
    catch (FileNotFoundException e) {
      //if we can't throw an exception
      throw new IllegalArgumentException("File " + filename + " not found!");
    }
    //if we can, create a sb
    StringBuilder builder = new StringBuilder();

    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0)!='#') {
        builder.append(s+System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    //token is the next value in the sb
    String token;

    token = sc.next();
    //if we're not in the right type of ppm, throw
    if (!token.equals("P3")) {
      throw new IllegalArgumentException("Invalid PPM file: plain RAW file should begin with P3");
    }
    //set our width
    int width = sc.nextInt();
    //set our height
    int height = sc.nextInt();
    //skip past the maxval
    int maxValue = sc.nextInt();
    //instantiate our pixel arr
    ArrayList<Pixel> pixels = new ArrayList<Pixel>();

    //assign our colors to pixels, our pixels positions, and our array of pixels.
    for (int y=0;y<height;y++) {
      for (int x=0;x<width;x++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        Color resCol = new ColorImpl(r,g,b);
        Posn posn = new PosnImpl(x,y);
        pixels.add(new PixelImpl(resCol, posn));
      }
    }
    //return an image with our width, height, and array of pixels
    return new ImageImpl(filename.substring(filename.lastIndexOf("/"), filename.length() - 4), pixels, width, height);
  }

  @Override
  public void write(Image object) {
    StringBuilder sb = new StringBuilder();
    sb.append("P3\n");
    sb.append("" + object.getWidth() + " ");
    sb.append("" + object.getHeight() + "\n");
    sb.append("" + 255 + "\n");
    for (int i = 0; i < object.getHeight() * object.getWidth(); i++) {
      sb.append("" + object.getPixels().get(i).getColor().getRed() + " ");
      sb.append("" + object.getPixels().get(i).getColor().getGreen() + " ");
      sb.append("" + object.getPixels().get(i).getColor().getBlue() + "\n");
    }

    FileOutputStream os = null;
    File output;

    try {
      //Specify the file path here
      output = new File("./res/" + object.getTitle() +".ppm");
      os = new FileOutputStream(output);

      if (!output.exists()) {
        output.createNewFile();
      }

      byte[] bytesArray = sb.toString().getBytes();

      os.write(bytesArray);
      os.flush();
      System.out.println("File Written Successfully");
    }
    catch (IOException ioe) {
      throw new IllegalArgumentException("File could not be written");
    }
    finally {
      try {
        if (os != null)
        {
          os.close();
        }
      }
      catch (IOException ioe) {
        throw new IllegalArgumentException("Output stream could not be closed");
      }
    }
  }
}
