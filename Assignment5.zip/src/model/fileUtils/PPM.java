package model.fileUtils;

import model.image.Image;

public class PPM implements FileType<Image> {

  @Override
  public Image read(String filename) {
    return null;
  }

  @Override
  public void write(Image object) {

  }
}
