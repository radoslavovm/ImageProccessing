package model;

import java.util.ArrayList;
import model.fileutils.FileType;
import model.fileutils.TXT;
import model.filters.FilterCommand;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import model.programmatics.Programmatic;

public class SimpleProcessingModel implements ProcessingModel {
  private ArrayList<Image> layers;
  private ArrayList<Image> resultants;
  private ArrayList<Programmatic> programmatics;
  private ArrayList<FilterCommand> filters;

  /**
   * Constructs a SimpleProcessingModel.
   *
   * @param image the image to process, defaults to null until loaded.
   * @param programmatics an arraylist of programmatics to support
   * @param filters an arraylist of filters to support
   */
  public SimpleProcessingModel(Image image, ArrayList<Programmatic> programmatics, ArrayList<FilterCommand> filters) {
    this.layers = new ArrayList<Image>();
    this.layers.add(image);
    this.resultants = new ArrayList<Image>();
    this.programmatics = programmatics;
    this.filters = filters;
  }

  @Override
  public void applyFilter(int imageIndex, int filterIndex) {
    resultants.add(this.getFilterAt(filterIndex).apply(this.getImageAt(imageIndex)));
  }

  @Override
  public void generate(int width, int height, int toGen) {
    this.resultants.add(this.getProgrammaticAt(toGen).generate(width, height));
  }

  @Override
  public void load(FileType<Image> fileType, String filename) {
    this.layers.add(fileType.read(filename));
  }

  @Override
  public void loadImage(Image image) {
    this.layers.add(image);
  }

  @Override
  public void save(FileType<Image> fileType) {
    for (Image image : this.resultants) {
      fileType.write(image);
    }
    this.resultants = new ArrayList<Image>();
    StringBuilder toWrite = new StringBuilder();
    int count = 0;
    for (Image layer : this.layers) {
      fileType.write(layer);
      toWrite.append("Layer " + count + ": " + layer.getTitle() +"\n");
      count++;
    }
    FileType<String> txt = new TXT();
    txt.write(toWrite.toString());
  }

  @Override
  public void addLayer() {
    if (this.getSizeLayers() == 0) {
      throw new IllegalArgumentException("Cannot add a layer to a non-existant image");
    }
    ArrayList<Pixel> toAdd = new ArrayList<Pixel>();
    for (int y = 0; y < this.getImageAt(0).getHeight(); y++) {
      for (int x = 0; x < this.getImageAt(0).getWidth(); x++) {
        toAdd.add(new PixelImpl(new ColorImpl(0,0,0), new PosnImpl(x,y)));
      }
    }
    this.layers.add(new ImageImpl("layer" + this.getSizeLayers(), toAdd, this.getImageAt(0).getWidth(), this.getImageAt(0).getHeight()));
  }

  @Override
  public void removeLayer(int index) {
    if (this.checkBounds(index, this.layers)) {
      this.layers.remove(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public int getNumProgrammatics() {
    return programmatics.size();
  }

  @Override
  public int getNumFilterCommands() {
    return filters.size();
  }

  @Override
  public int getSizeOfResultants() {
    return this.resultants.size();
  }

  @Override
  public int getSizeLayers() {
    return this.layers.size();
  }

  @Override
  public Programmatic getProgrammaticAt(int index) {
    if (this.checkBounds(index, this.programmatics)) {
      return this.programmatics.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public FilterCommand getFilterAt(int index) {
    if (this.checkBounds(index, this.filters)) {
      return this.filters.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public Image getImageAt(int index) {
    if (this.checkBounds(index, this.layers)) {
      return this.layers.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public Image getResultantImageAt(int index) {
    if (this.checkBounds(index, this.resultants)) {
      return this.resultants.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  /**
   * Checks the if the index is valid given the list.
   *
   * @param index the index to check
   * @param list the list to check against
   *
   * @return true if the index is inbounds, false if not.
   */
  private boolean checkBounds(int index, ArrayList list) throws IllegalArgumentException {
    return index < list.size() && index >= 0;
  }
}
