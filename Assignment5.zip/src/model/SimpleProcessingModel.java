package model;

public class SimpleProcessingModel implements ProcessingModel {

}
