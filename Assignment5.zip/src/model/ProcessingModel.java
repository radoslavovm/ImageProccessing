package model;

import model.fileUtils.FileType;
import model.filters.FilterCommand;
import model.image.Image;
import model.programmatics.Programmatic;

/**
 * Represents an interface for an Image processing model. Supports import, export, generation, and
 * filtering.
 */
public interface ProcessingModel {
  /**
   * Applies the given FilterCommand to the given Image and returns its result.
   *
   * @param image the Image to be filtered
   * @param filter the FilterCommand object used to filter the Image
   *
   * @return an Image object with the applied filter
   */
  Image applyFilter(Image image, FilterCommand filter);

  /**
   * Generates an Image given the desired width, desired height, and desired ProgrammaticType.
   *
   * @param width the width of the Image
   * @param height the height of the Image
   * @param toGen the Programmatic to generate
   *
   * @return an Image generated with the desired Programmatic
   */
  Image generate(int width, int height, Programmatic toGen);

  /**
   * Imports the file from the given name and converts it to an Image object.
   *
   * @param fileType the fileType of the file to load.
   * @param filename the String of the filepath.
   *
   * @return an Image object loaded from the file provided
   * @throws IllegalArgumentException if the file is of an improper type
   * @throws java.io.FileNotFoundException if the file cannot be found
   */
  Image load(FileType<Image> fileType, String filename);

  /**
   * Exports the Image to a file given the desired filetype.
   *
   * @param fileType the desired fileType to save the image to
   * @param image the Image to save
   */
  void save(FileType<Image> fileType, Image image);
}
