package model.programmatics;

import java.util.ArrayList;
import model.image.Pixel;

public interface Programmatic {
  /**
   * Generates the programmatic Object and returns its data as an ArrayList(Pixel).
   *
   * @return an ArrayList(Pixel) representing the generated image data
   */
  ArrayList<Pixel> generate();
}
