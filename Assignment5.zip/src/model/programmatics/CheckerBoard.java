package model.programmatics;

import java.util.ArrayList;
import model.image.Pixel;

public class CheckerBoard implements Programmatic {

  @Override
  public ArrayList<Pixel> generate() {
    return null;
  }
}
