package model.filters;

import model.image.Image;

/**
 * Represents a filter on an image.
 */
public interface FilterCommand {
  /**
   * Applies the filter object on the Image provided.
   */
  void apply(Image image);
}
