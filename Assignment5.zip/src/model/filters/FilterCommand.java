package model.filters;

import java.util.ArrayList;
import model.image.Image;
import model.image.Pixel;

/**
 * Represents a filter on an image.
 */
public interface FilterCommand {
  /**
   * Applies the filter object on the Image provided.
   *
   * @param image the Image to filter
   *
   * @return an ArrayList(Pixel) that contains the filtered Image's raw pixels
   *
   * @throws IllegalArgumentException if the image is null
   */
  Image apply(Image image);
}
