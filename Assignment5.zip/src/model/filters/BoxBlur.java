package model.filters;

import model.filters.FilterCommand;
import model.image.Image;

public class BoxBlur implements FilterCommand {

  @Override
  public void apply(Image image) {
    //Martina
  }
}
