package model.filters;

import java.util.ArrayList;
import model.filters.FilterCommand;
import model.image.Image;
import model.image.Pixel;

public class BoxBlur implements FilterCommand {

  @Override
  public Image apply(Image image) {
    return null;
  }
}
