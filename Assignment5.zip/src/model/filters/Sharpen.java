package model.filters;

import model.filters.FilterCommand;
import model.image.Image;
import model.image.Pixel;

public class Sharpen implements FilterCommand {

  @Override
  public Image apply(Image image) {
    return null;
  }
}
