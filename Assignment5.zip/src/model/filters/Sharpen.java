package model.filters;
import java.util.ArrayList;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
public class Sharpen implements FilterCommand {
  @Override
  public Image apply(Image image) {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    ArrayList<Pixel> result = new ArrayList<>();
    double red;
    double green;
    double blue;
    Color color;
    Pixel newPixel;
    for (int i=0; i < image.getHeight(); i++) {
      for (int j=0; j < image.getWidth(); j++) {
        if (i < 2 || j < 2 || i > image.getHeight() - 3 || j > image.getWidth() - 3) {
          newPixel = new PixelImpl(image.getPixels().get((i) * image.getWidth() + (j)).getColor(),
              image.getPixels().get((i) * image.getWidth() + (j)).getPosn());
          result.add(newPixel);
          continue;
        }
        Color tl00 = image.getPixels().get((i - 2) * image.getWidth() + (j -2)).getColor();
        Color tl10 = image.getPixels().get((i - 2) * image.getWidth() + (j -1)).getColor();
        Color tm20 = image.getPixels().get((i - 2) * image.getWidth() + (j)).getColor();
        Color tr30 = image.getPixels().get((i - 2) * image.getWidth() + (j + 1)).getColor();
        Color tr40 = image.getPixels().get((i - 2) * image.getWidth() + (j + 2)).getColor();
        Color tl01 = image.getPixels().get((i - 1) * image.getWidth() + (j - 2)).getColor();
        Color tl11 = image.getPixels().get((i - 1) * image.getWidth() + (j - 1)).getColor();
        Color tm21 = image.getPixels().get((i - 1) * image.getWidth() + (j)).getColor();
        Color tr31 = image.getPixels().get((i - 1) * image.getWidth() + (j + 1)).getColor();
        Color tr41 = image.getPixels().get((i - 1) * image.getWidth() + (j + 2)).getColor();
        Color ml02 = image.getPixels().get((i) * image.getWidth() + (j -2)).getColor();
        Color ml12 = image.getPixels().get((i) * image.getWidth() + (j -1)).getColor();
        Color pixel22 = image.getPixels().get((i) * image.getWidth() + (j)).getColor();
        Color mr32 = image.getPixels().get((i) * image.getWidth() + (j +1)).getColor();
        Color mr42 = image.getPixels().get((i) * image.getWidth() + (j +2)).getColor();
        Color bl03 = image.getPixels().get((i+1) * image.getWidth() + (j -2)).getColor();
        Color bl13 = image.getPixels().get((i+1) * image.getWidth() + (j -1)).getColor();
        Color bm23 = image.getPixels().get((i+1) * image.getWidth() + (j)).getColor();
        Color br33 = image.getPixels().get((i+1) * image.getWidth() + (j +1)).getColor();
        Color br43 = image.getPixels().get((i+1) * image.getWidth() + (j +1)).getColor();
        Color bl04 = image.getPixels().get((i+2) * image.getWidth() + (j -2)).getColor();
        Color bl14 = image.getPixels().get((i+2) * image.getWidth() + (j -1)).getColor();
        Color bm24 = image.getPixels().get((i+2) * image.getWidth() + (j)).getColor();
        Color br34 = image.getPixels().get((i+2) * image.getWidth() + (j +1)).getColor();
        Color br44 = image.getPixels().get((i+2) * image.getWidth() + (j +2)).getColor();

        red = (-1 * 0.125)
            * (tl00.getRed() + tl10.getRed() + tm20.getRed() + tr30.getRed() + tr40.getRed()
            + tl01.getRed() + (tl11.getRed() * -2) + (tm21.getRed() * -2) + (tr31.getRed() * -2) + tr41.getRed()
            + ml02.getRed() + (ml12.getRed() * -2) + (pixel22.getRed() * -8) + (mr32.getRed() * -2) + mr42.getRed()
            + bl03.getRed() + (bl13.getRed() * -2) + (bm23.getRed() * -2) + (br33.getRed() * -2) + br43.getRed()
            + bl04.getRed() + bl14.getRed() + bm24.getRed() + br34.getRed() + br44.getRed());
        green = (-1 * 0.125)
            * (tl00.getGreen() + tl10.getGreen() + tm20.getGreen() + tr30.getGreen() + tr40.getGreen()
            + tl01.getGreen() + (tl11.getGreen() * -2) + (tm21.getGreen() * -2) + (tr31.getGreen() * -2) + tr41.getGreen()
            + ml02.getGreen() + (ml12.getGreen() * -2) + (pixel22.getGreen() * -8) + (mr32.getGreen() * -2) + mr42.getGreen()
            + bl03.getGreen() + (bl13.getGreen() * -2) + (bm23.getGreen() * -2) + (br33.getGreen() * -2) + br43.getGreen()
            + bl04.getGreen() + bl14.getGreen() + bm24.getGreen() + br34.getGreen() + br44.getGreen());
        blue = (-1 * 0.125)
            * (tl00.getBlue() + tl10.getBlue() + tm20.getBlue() + tr30.getBlue() + tr40.getBlue()
            + tl01.getBlue() + (tl11.getBlue() * -2) + (tm21.getBlue() * -2) + (tr31.getBlue() * -2) + tr41.getBlue()
            + ml02.getBlue() + (ml12.getBlue() * -2) + (pixel22.getBlue() * -8) + (mr32.getBlue() * -2) + mr42.getBlue()
            + bl03.getBlue() + (bl13.getBlue() * -2) + (bm23.getBlue() * -2) + (br33.getBlue() * -2) + br43.getBlue()
            + bl04.getBlue() + bl14.getBlue() + bm24.getBlue() + br34.getBlue() + br44.getBlue());
        color = new ColorImpl(Color.clamp((int)red), Color.clamp((int)green), Color.clamp((int)blue));
        newPixel = new PixelImpl(color, new PosnImpl(j, i));
        result.add(newPixel);
      }
    }
    return new ImageImpl(image.getTitle() + "sharpen", result, image.getWidth(), image.getHeight());
  }
}
