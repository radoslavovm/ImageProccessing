package model.filters;

import java.util.ArrayList;
import model.filters.FilterCommand;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;

public class Grayscale implements FilterCommand {

  @Override
  public Image apply(Image image) {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    ArrayList<Pixel> resultant = new ArrayList<Pixel>();
    for (Pixel pixel : image.getPixels()) {
      int r = pixel.getColor().getRed();
      int g = pixel.getColor().getGreen();
      int b = pixel.getColor().getBlue();
      int grayVal = Color.clamp((int)((0.2126 * r) + (0.7152 * g) + (0.0722 * b)));
      Color newCol = new ColorImpl(grayVal, grayVal, grayVal);
      resultant.add(new PixelImpl(newCol, pixel.getPosn()));
    }
    return new ImageImpl(image.getTitle() + "Grayscale", resultant, image.getWidth(), image.getHeight());
  }
}
