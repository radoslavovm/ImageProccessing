package model.filters;

import model.filters.FilterCommand;
import model.image.Image;

public class Grayscale implements FilterCommand {

  @Override
  public void apply(Image image) {
    //Ben
  }
}
