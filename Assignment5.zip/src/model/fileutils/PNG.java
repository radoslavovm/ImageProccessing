package model.fileutils;

import model.image.Image;

public class PNG implements FileType<Image> {

  @Override
  public Image read(String filename) {
    return null;
  }

  @Override
  public void write(Image toWrite) {

  }
}
