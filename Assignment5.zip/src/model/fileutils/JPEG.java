package model.fileutils;

import model.image.Image;

public class JPEG implements FileType<Image> {

  @Override
  public Image read(String filename) {
    return null;
  }

  @Override
  public void write(Image toWrite) {

  }
}
