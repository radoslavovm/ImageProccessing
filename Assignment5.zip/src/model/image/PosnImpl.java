package model.image;

/**
 * Represents an (x,y) position. Any methods in this class represent their origin at the top left.
 * Positions in this class must have positive x and y values.
 */
public class PosnImpl implements Posn {
  private int x;
  private int y;

  PosnImpl(int x, int y) {
    if (x < 0 || y < 0) {
      throw new IllegalArgumentException("Invalid coordinate, negative in one or both positions");
    }
    this.x = x;
    this.y = y;
  }

  @Override
  public int getXPos() {
    //Martina
    return 0;
  }

  @Override
  public int getYPos() {
    return 0;
  }

  @Override
  public void setXPos() {

  }

  @Override
  public void setYPos() {

  }
}
