package model.image;

public class PixelImpl implements Pixel {
  private Color color;
  private Posn posn;

  PixelImpl(Color color, Posn posn) {
    this.color = color;
    this.posn = posn;
  }

  @Override
  public Color getColor() {
    //Martina
    return null;
  }

  @Override
  public Posn getPosn() {
    return null;
  }
}
