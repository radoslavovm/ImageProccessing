package model.image;

public class PixelImpl implements Pixel {
  private Color color;
  private Posn posn;

  public PixelImpl(Color color, Posn posn) {
    this.color = color;
    this.posn = posn;
  }

  @Override
  public Color getColor() {
    //Martina
    return this.color;
  }

  @Override
  public Posn getPosn() {
    return this.posn;
  }
}
