package model.image;

import java.util.ArrayList;
import model.filters.FilterCommand;
import model.programmatics.Programmatic;

public class ImageImpl implements Image {
  private ArrayList<Pixel> pixels;
  private int width;
  private int height;

  /**
   * Constructor to construct an image with a list of pixels, a width, and a height.
   *
   * @param pixels
   * @param width
   * @param height
   */
  public ImageImpl(ArrayList<Pixel> pixels, int width, int height) {
    if (width * height != pixels.size()) {
      throw new IllegalArgumentException("Image and dimensions don't match");
    }
    this.pixels = pixels;
    this.width = width;
    this.height = height;
  }

  @Override
  public int getWidth() {
    return this.width;
  }

  @Override
  public int getHeight() {
    return this.height;
  }

  @Override
  public ArrayList<Pixel> getPixels() {
    ArrayList<Pixel> resultant = new ArrayList<Pixel>();
    for (Pixel pixel : this.pixels) {
      Color newCol = new ColorImpl(pixel.getColor().getRed(), pixel.getColor().getGreen(), pixel.getColor().getBlue());
      resultant.add(new PixelImpl(newCol, pixel.getPosn()));
    }
    return resultant;
  }
}
