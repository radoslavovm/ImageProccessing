package model.image;

import java.util.ArrayList;
import model.filters.FilterCommand;

public class ImageImpl implements Image {
  private ArrayList<Pixel> pixels;
  private int width;
  private int height;

  ImageImpl(int width, int height) {
    this.pixels = new ArrayList<Pixel>();
    this.width = width;
    this.height = height;
  }

  ImageImpl(ArrayList<Pixel> pixels, int width, int height) {
    if (width * height != pixels.size()) {
      throw new IllegalArgumentException("Image and dimensions don't match");
    }
    this.pixels = pixels;
    this.width = width;
    this.height = height;
  }

  @Override
  public void applyFilter(FilterCommand filter) {

  }

  @Override
  public int getWidth() {
    return 0;
  }

  @Override
  public int getHeight() {
    return 0;
  }
}
