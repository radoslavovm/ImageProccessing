package model.image;

/**
 * An RGB implementation of the Color interface. Objects of this class have a red, green, and blue
 * value represented as integers. No field of this class can be greater than 255 or less than 0.
 */
public class ColorImpl implements Color {
  private int r;
  private int g;
  private int b;

  ColorImpl(int r, int g, int b) {
    this.r = this.clamp(r);
    this.g = this.clamp(g);
    this.b = this.clamp(b);
  }

  /**
   * Clamps the integer value to 0-255.
   *
   * @param chanVal the channelValue to clamp
   * @return a 0-255 integer representing a color channel value.
   */
  private int clamp(int chanVal) {
    if (chanVal < 0) {
      return 0;
    }
    else if (chanVal > 255) {
      return 255;
    }
    else {
      return chanVal;
    }
  }

  @Override
  public int getRed() {

    //Ben
    return 0;
  }

  @Override
  public int getGreen() {
    return 0;
  }

  @Override
  public int getBlue() {
    return 0;
  }

  @Override
  public void setRed() {

  }

  @Override
  public void setGreen() {

  }

  @Override
  public void setBlue() {

  }
}
