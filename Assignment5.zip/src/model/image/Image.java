package model.image;

import java.util.ArrayList;
import model.filters.FilterCommand;

/**
 * Represents an image of various formats.
 */
public interface Image {

  /**
   * Gets the width of the Image object.
   *
   * @return an integer representing the Image's width in Pixels
   */
  int getWidth();

  /**
   * Gets the height of the Image object.
   *
   * @return an integer representing the Image's height in Pixels
   */
  int getHeight();

  /**
   * Gets a copy of the Image's pixels.
   *
   * @return an ArrayList(Pixel) representation of the image.
   */
  ArrayList<Pixel> getPixels();
}
