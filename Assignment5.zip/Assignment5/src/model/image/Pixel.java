package model.image;

/**
 * Represents a pixel and its values.
 */
public interface Pixel {
  /**
   * Gets the color of the Pixel object.
   *
   * @return a Color object representing the color of the Pixel.
   */
  Color getColor();

  /**
   * Gets the position of the Pixel object.
   *
   * @return a Posn object representing the Pixel's location.
   */
  Posn getPosn();
}
