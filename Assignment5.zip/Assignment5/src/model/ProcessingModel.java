package model;

import model.fileutils.FileType;
import model.filters.FilterCommand;
import model.image.Image;

/**
 * Represents an interface for an Image processing model. Supports import, export, generation, and
 * filtering.
 */
public interface ProcessingModel extends ProcessingModelState {
  /**
   * Applies the given FilterCommand to the given Image and returns its result.
   *
   * @param imageIndex the index of the image layer to apply the filter to
   * @param filterIndex the index of the filter to use
   */
  void applyFilter(int imageIndex, int filterIndex);

  /**
   * Generates an Image given the desired width, desired height, and desired ProgrammaticType.
   *
   * @param width the width of the Image
   * @param height the height of the Image
   * @param toGen index of the programmatic to generate
   */
  void generate(int width, int height, int toGen);

  /**
   * Imports the file from the given name and converts it to an Image object.
   *
   * @param fileType the fileType of the file to load.
   * @param filename the String of the filepath.
   *
   * @throws IllegalArgumentException if the file is of an improper type
   * @throws java.io.FileNotFoundException if the file cannot be found
   */
  void load(FileType<Image> fileType, String filename);

  /**
   * Loads an Image into the model.
   *
   * @param image the image to load
   */
  void loadImage(Image image);

  /**
   * Exports an Image to a file of the given filetype
   *
   * @param fileType the desired fileType to save the image to
   */
  void save(FileType<Image> fileType);

  /**
   * Adds a layer to the image, initially populates this layer with all black pixels.
   */
  void addLayer();

  /**
   * Removes the corresponding layer from the image, given its index.
   *
   * @param index representing the layer to remove
   * @throws IllegalArgumentException if the index is OOB
   */
  void removeLayer(int index);
}
