package model.filters;

import java.util.ArrayList;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;

/**
 * define gaussian_blur matrix (1, 2, 1, 2, 4, 2, 1, 2, 1) * 0.0625
 */
public class GaussianBlur implements FilterCommand {

  @Override
  public Image apply(Image image) {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    ArrayList<Pixel> result = new ArrayList<>();
    int red;
    int green;
    int blue;
    Color color;
    Pixel newPixel;
    int width;
    ArrayList<Pixel> p = image.getPixels();
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        if (i == 0 || j == 0 || i == image.getHeight() - 1 || j == image.getWidth() - 1) {
          newPixel = new PixelImpl(image.getPixels().get((i) * image.getWidth() + (j)).getColor(),
              image.getPixels().get((i) * image.getWidth() + (j)).getPosn());
          result.add(newPixel);
          continue;
        }
        width = image.getWidth();
        Color tl = p.get((i - 1) * width + (j - 1)).getColor();
        Color tm = p.get((i - 1) * width + (j)).getColor();
        Color tr = p.get((i - 1) * width + (j + 1)).getColor();
        Color ml = p.get((i) * width + (j - 1)).getColor();
        Color m = p.get((i) * width + (j)).getColor();
        Color mr = p.get((i) * width + (j + 1)).getColor();
        Color bl = p.get((i + 1) * width + (j - 1)).getColor();
        Color bm = p.get((i + 1) * width + (j)).getColor();
        Color br = p.get((i + 1) * width + (j + 1)).getColor();
        red = (int) Math.round((0.0625) * (tl.getRed() + (tm.getRed() * 2) +
            tr.getRed() + (ml.getRed() * 2) + (m.getRed() * 4) + (mr.getRed() * 2) +
            bl.getRed() + (bm.getRed() * 2) + br.getRed()));
        green = (int) Math.round((0.0625) * (tl.getGreen() + (tm.getGreen() * 2) +
            tr.getGreen() + (ml.getGreen() * 2) + (m.getGreen() * 4) + (mr.getGreen() * 2) +
            bl.getGreen() + (bm.getGreen() * 2) + br.getGreen()));
        blue = (int) Math.round((0.0625) * (tl.getBlue() + (tm.getBlue() * 2) +
            tr.getBlue() + (ml.getBlue() * 2) + (m.getBlue() * 4) + (mr.getBlue() * 2) +
            bl.getBlue() + (bm.getBlue() * 2) + br.getBlue()));
        color = new ColorImpl(red, green, blue);
        newPixel = new PixelImpl(color, new PosnImpl(j, i));
        result.add(newPixel);
      }
    }
    return new ImageImpl(image.getTitle() + "blur", result, image.getWidth(), image.getHeight());
  }
}
