package model.filters;

import java.util.ArrayList;
import model.image.Image;

/**
 * Interface of filterCommand objects meant to work with multiple layers.
 */
public interface MultiLayerFilterCommand {
  /**
   * Applies the filter object on the Image layers inputted.
   *
   * @param layers an ArrayList(Image) representing a multilayered image
   */
  Image apply(ArrayList<Image> layers);
}
