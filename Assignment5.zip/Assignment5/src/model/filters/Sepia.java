package model.filters;

import java.util.ArrayList;
import model.filters.FilterCommand;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;

public class Sepia implements FilterCommand {

  @Override
  public Image apply(Image image) {
    if (image == null) {
      throw new IllegalArgumentException("Image is null");
    }
    ArrayList<Pixel> resultant = new ArrayList<Pixel>();
    for (Pixel pixel : image.getPixels()) {
      int r = pixel.getColor().getRed();
      int g = pixel.getColor().getGreen();
      int b = pixel.getColor().getBlue();
      int redVal = Color.clamp((int)((0.393 * r) + (0.769 * g) + (0.189 * b)));
      int greenVal = Color.clamp((int)((0.349 * r) + (0.686 * g) + (0.168 * b)));
      int blueVal = Color.clamp((int)((0.272 * r) + (0.534 * g) + (0.131 * b)));
      Color newCol = new ColorImpl(redVal, greenVal, blueVal);
      resultant.add(new PixelImpl(newCol, pixel.getPosn()));
    }
    return new ImageImpl(image.getTitle() + "Sepia", resultant, image.getWidth(), image.getHeight());
  }
}
