package model;

import model.filters.FilterCommand;
import model.image.Image;
import model.programmatics.Programmatic;

/**
 * Contains methods for the state of the processing model.
 */
public interface ProcessingModelState {
  /**
   * Gets the amount of supported Programmatics.
   *
   * @return the number of supported Programmatics
   */
  int getNumProgrammatics();

  /**
   * Gets the amount of supported FilterCommands.
   *
   * @return the number of supported FilterCommands
   */
  int getNumFilterCommands();

  /**
   * Gets the size of the resultant list.
   *
   * @return an int representing the size of the resultant list
   */
  int getSizeOfResultants();

  /**
   * Gets the amount of layers an image has.
   *
   * @return an int representing the number of layers an image has
   */
  int getSizeLayers();

  /**
   * Gets the Programmatic at the given index.
   *
   * @return the Programmatic object at the given index.
   * @throws IllegalArgumentException if the index is out of bounds
   */
  Programmatic getProgrammaticAt(int index);

  /**
   * Gets the Filter at the given index.
   *
   * @return the FilterCommand at the given index
   * @throws IllegalArgumentException if the index is out of bounds
   */
  FilterCommand getFilterAt(int index);

  /**
   * Gets the layer of the image at the given index.
   *
   * @param index the index of the requested image
   * @throws IllegalArgumentException if the index is out of bounds
   */
  Image getImageAt(int index);

  /**
   * Gets the Resultant image at the given index.
   *
   * @param index the index of the requested image
   * @throws IllegalArgumentException if the index is out of bounds
   */
  Image getResultantImageAt(int index);

}
