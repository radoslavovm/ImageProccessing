import controller.ProcessingController;
import controller.SimpleProcessingController;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.fileutils.FileType;
import model.fileutils.JPEG;
import model.fileutils.PNG;
import model.fileutils.PPM;
import model.fileutils.TXT;
import model.filters.FilterCommand;
import model.filters.GaussianBlur;
import model.filters.Grayscale;
import model.filters.Sepia;
import model.filters.Sharpen;
import model.image.ColorImpl;
import model.image.Image;
import model.programmatics.CheckerBoard;
import model.programmatics.Programmatic;
import view.ProcessingView;
import view.SimpleProcessingTextView;

public class main {
  //demo main
  public static void main(String []args) {

    Readable toUse = null;
    if (args.length > 0) {
      if (args[0].equals("-script")) {
        FileType<String> txt = new TXT();
        String script = txt.read(args[1]);
        toUse = new StringReader(script);
      } else {
        toUse = new InputStreamReader(System.in);
      }
    }
    FileType<Image> ppm = new PPM();
    FileType<Image> jpeg = new JPEG();
    FileType<Image> png = new PNG();

    FilterCommand gray = new Grayscale();
    FilterCommand sepia = new Sepia();
    FilterCommand gaussianBlur = new GaussianBlur();
    FilterCommand sharpen = new Sharpen();

    int count = 0;
    Programmatic checker = new CheckerBoard(10, 10, new ColorImpl(0, 0, 0), new ColorImpl(255,255,255));

    if (toUse == null) {
      toUse = new InputStreamReader(System.in);
    }
    ProcessingModel spm = new SimpleProcessingModel(null, new ArrayList<Programmatic>(
        Arrays.asList(checker)), new ArrayList<FilterCommand>(Arrays.asList(gray,sepia,gaussianBlur,sharpen)), new ArrayList<FileType<Image>>(Arrays.asList(ppm, jpeg, png)));
    ProcessingController spc = new SimpleProcessingController<Image>(spm, toUse, System.out);
    ProcessingView spv = new SimpleProcessingTextView(spm, System.out);

    spc.run();
    if (spm.getSizeLayers() == 2 && count == 0) {
      spm.removeLayer(0);
      count++;
    }
  }
}
