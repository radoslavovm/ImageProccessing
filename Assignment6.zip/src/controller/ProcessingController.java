package controller;

import model.fileutils.FileType;
import model.image.Image;

/**
 * Represents a controller for a processing model. Handles input, output, and operation performance.
 */
public interface ProcessingController {
  /**
   * Imports the file from the given name and converts it to an Image object and adds it to the model.
   *
   * @param fileType the fileType of the file to load.
   * @param filename the String of the filepath.
   *
   * @throws IllegalArgumentException if the file is of an improper type
   * @throws java.io.FileNotFoundException if the file cannot be found
   */
  void load(FileType<Image> fileType, String filename);

  /**
   * Exports an Image to a file of the given filetype.
   *
   * @param fileTypeIndex the index of the desired file format to save to.
   * @param filePath the designated filePath to save to
   */
  void save(int fileTypeIndex, String filePath);

  /**
   * Runs the controller.
   */
  void run();
}
