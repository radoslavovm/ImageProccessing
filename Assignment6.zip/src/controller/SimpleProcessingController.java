package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.fileutils.FileType;
import model.image.Image;
import view.ProcessingView;
import view.SimpleProcessingTextView;

public class SimpleProcessingController<K> implements ProcessingController {
  ProcessingModel model;
  ProcessingView view;
  Readable readable;


  /**
   * Constructs a SimpleProcessingController given a model, readable, and appendable.
   *
   * @param model the model to control
   * @param readable the script/interactive file to use
   * @param appendable the appendable to construct the view with
   * @throws IllegalArgumentException if any parameter is null
   */
  public SimpleProcessingController(ProcessingModel model, Readable readable, Appendable appendable) {
    if (model == null || readable == null || appendable == null) {
      throw new IllegalArgumentException("Null parameter to controller");
    }
    this.model = model;
    this.readable = readable;
    this.view = new SimpleProcessingTextView(this.model, appendable);
  }

  @Override
  public void load(FileType<Image> fileType, String filename) {
    this.model.load(fileType, filename);
  }

  @Override
  public void save(int fileTypeIndex) {
    this.model.save(fileTypeIndex);
  }

  @Override
  public void run() {
    /**
     * create -
     *        ---> layer ---> (integer representing 1 based index)
     *        ---> programmatic ---> checkerboard ---> int rep width ---> int rep height ---> int rep index of checkerboard
     *                          ---> rainbow ---> int rep width --->
     *
     * remove -
     *        ---> integer index representing layer to delete
     *
     * current -
     *         ---> (integer representing 1 based index)
     *
     * load -
     *      ---> image ---> integer representing resultant index
     *      ---> file ---> string representing filePath
     *
     * save -
     *      ---> title of the image ---> integer index of requested file export type
     *
     * filter -
     *        ---> int index of the image to filter --> string of filter to use (compared to toString())
     *
     * # -
     *   ---> ignore the rest of the line
     *
     */

    this.tryRenderModel();
    Scanner sc = new Scanner(this.readable);

    int argCount = 0;

    while (sc.hasNext()) {
      switch (argCount) {
        case 0: argCount = this.scanHighLevelCmds(sc);
        //scanning high level cmds
          break;
        case 1: if (this.scanCreateCmds(sc)) {
                  argCount = 0;
                }
        //scanning parameters to create
          break;
        case 2: this.scanCurrentCmds(sc);
        //scanning parameters to current
          break;
        case 3: this.scanLoadCmds(sc);
        //scanning parameters to load
          break;
        case 4: this.scanSaveCmds(sc);
        //scanning parameters to save
          break;
        case 5: this.scanFilterCmds(sc);
        //scanning parameters to filter
          break;
        case 6: sc.nextLine();
                argCount = 0;
        //ignore the rest of the line
          break;
        default:
          throw new IllegalArgumentException("Failed to parse command");
          break;
      }
      this.tryRenderModel();
    }
  }

  /**
   * Scans for the high level commands, returns the integer of the corresponding command.
   *
   * @param sc the scanner to parse
   * @return an integer representing which argument to move on to next
   */
  private int scanHighLevelCmds(Scanner sc) {
    String cmd = sc.next();
    int resultant = 0;
    switch (cmd) {
      case "create": resultant = 1;
        break;
      case "current": resultant = 2;
        break;
      case "load": resultant = 3;
        break;
      case "save": resultant = 4;
        break;
      case "filter": resultant = 5;
        break;
      case "#": resultant = 6;
        break;
      default:
        this.tryRenderMessage("Please input a valid starting command. (create, current, load, save, filter, #)");
        this.tryRenderModel();
        break;
    }
    return resultant;
  }

  /**
   * Scans until a valid command can be read for create. If no valid command can be executed, returns false.
   * If a valid command is parsed, it will be executed.
   * @param sc
   * @return true if a command has been executed, false if not
   *
   * @throws IllegalArgumentException if the scanner doesn't have enough inputs to fill the cmd
   */
  private boolean scanCreateCmds(Scanner sc) {
    String cmd = sc.next();

    boolean executed = false;
    if (cmd.equals("layer")) {
      try{
        this.model.addLayer();
        executed = true;
      }
      catch (IllegalArgumentException e) {
        this.tryRenderMessage("Please load an image before creating a layer");
      }
    }
    else if (cmd.equals("programmatic")) {
      try {
        String progType = sc.next();
        try {
          this.executeGeneration(progType, sc);
          executed = true;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("invalid generation, try again");
        }
      }
      catch (InputMismatchException e) {
        this.tryRenderMessage("Please input a valid layer index");
      }
      catch (NoSuchElementException e) {
        throw new IllegalArgumentException("scanner ran out of input");
      }
    }
    else {
      this.tryRenderMessage("Please input a valid create subcommand (layer, programmatic)");
    }
    return executed;
  }


  private void executeGeneration(String progType, Scanner sc) throws IllegalArgumentException {
    int count = 0;
    int width = -1;
    int height = -1;
    int progIndex = this.model.getProgrammaticIndexOf(progType);
    if (progIndex == -1) {
      this.tryRenderMessage("Please input a valid programmatic");
      return;
    }
    try {
      width = sc.nextInt();
      count++;
      height = sc.nextInt();
      count++;
      progIndex = sc.nextInt();
    }
    catch (InputMismatchException e) {
      if (count == 0) {
        this.tryRenderMessage("Please input a valid width");
        return;
      }
      else if (count == 1) {
        this.tryRenderMessage("Please input a valid height");
        return;
      }
      else if (count == 2) {
        this.tryRenderMessage("Please input a valid programmatic index")
      }
      else {
        throw new IllegalArgumentException("Scanner cannot be parsed");
      }
    }
    catch (NoSuchElementException e) {
      throw new IllegalArgumentException ("Scanner has no more input:/");
    }
    this.model.generate(width,height,progIndex);
  }

  private void tryRenderMessage(String message) {
    try {
      this.view.renderMessage(message);
    }
    catch (IOException e) {
      throw new IllegalArgumentException("Cannot write to appendable");
    }
  }

  private void tryRenderModel() {
    try {
      this.view.renderModel();
    }
    catch (IOException e) {
      throw new IllegalArgumentException("Cannot write to appendable");
    }
  }
}
