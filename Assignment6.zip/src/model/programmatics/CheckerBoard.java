package model.programmatics;

import java.util.ArrayList;
import model.image.Color;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;

/**
 * Represents a way to make a checkerboard image programmatically.
 */
public class CheckerBoard implements Programmatic {

  private final int sizePerSq;
  private final int numSquares;
  private final Color lightCol;
  private final Color darkCol;

  /**
   * Constructs a checkerBoard programmatic.
   * @param sizePerSq the amount of pixels per square
   * @param numSquares the number of squares
   * @param lightCol the first color
   * @param darkCol the second color
   * @throws IllegalArgumentException if the num of squares is not even.
   */
  public CheckerBoard(int sizePerSq, int numSquares, Color lightCol, Color darkCol) {
    if (numSquares % 2 != 0) {
      throw new IllegalArgumentException("can't have an odd amount of squares");
    }
    this.sizePerSq = sizePerSq;
    this.numSquares = numSquares;
    this.lightCol = lightCol;
    this.darkCol = darkCol;
  }

  @Override
  public Image generate(int width, int height) {
    if (width * height != sizePerSq * sizePerSq * numSquares) {
      throw new IllegalArgumentException("Checkerboard can't fit inside those dimensions");
    }
    ArrayList<Pixel> resultant = new ArrayList<Pixel>();
    int countX = 0;
    int countY = 0;
    boolean dark = true;
    for (int y = 0; y < height; y++) {
      if (countY == sizePerSq) {
        countY = 0;
        dark = !dark;
      }
      for (int x = 0; x < width; x++) {
        if (countX == sizePerSq) {
          countX = 0;
          dark = !dark;
        }
        if (dark) {
          resultant.add(new PixelImpl(darkCol, new PosnImpl(x, y)));
        }
        else {
          resultant.add(new PixelImpl(lightCol, new PosnImpl(x, y)));
        }
        countX++;
      }
      countY++;
    }
    return new ImageImpl("CheckerBoard", resultant, width, height);
  }

  @Override
  public String toString() {
    return "Checkerboard";
  }


}
