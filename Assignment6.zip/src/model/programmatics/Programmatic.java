package model.programmatics;

import java.util.ArrayList;
import model.image.Image;
import model.image.Pixel;

public interface Programmatic {
  /**
   * Generates the Image of given width and height and returns its data as an ArrayList(Pixel).
   *
   * @param width integer of the width in pixels
   * @param height integer of the height in pixels
   * @return an ArrayList(Pixel) representing the generated image data
   */
  Image generate(int width, int height);
}
