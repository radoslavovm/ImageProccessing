package model.fileutils;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import model.image.Color;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;

public class PNG implements FileType<Image> {

  @Override
  public Image read(String filename) {
    BufferedImage image = null;
    ArrayList<Pixel> pixels = new ArrayList<>();

    //read image into BufferedImage
    try {
      image = ImageIO.read(new File(filename));
    } catch (IOException e) {
    }

    //set the width and height
    int height = image.getHeight();
    int width = image.getWidth();

    for (int y=0;y<height;y++) {
      for (int x=0;x<width;x++) {
        java.awt.Color c = new java.awt.Color(image.getRGB(x,y));
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        Color resCol = new ColorImpl(r,g,b);
        Posn posn = new PosnImpl(x,y);
        pixels.add(new PixelImpl(resCol, posn));
      }
    }

    //return an image with our width, height, and array of pixels
    return new ImageImpl(filename.substring(filename.lastIndexOf("/"), filename.length() - 5),
        pixels, width, height);
  }

  @Override
  public void write(Image toWrite, String filePath) {
    try {
      int height = toWrite.getHeight();
      int width = toWrite.getWidth();
      ArrayList<Pixel> pixels = toWrite.getPixels();
      Pixel p;
      int r;
      int g;
      int b;

      File outputfile = new File(filePath + toWrite.getTitle() + ".png");
      BufferedImage buffImg = new BufferedImage(toWrite.getWidth(), toWrite.getHeight(), BufferedImage.TYPE_INT_RGB);
      WritableRaster raster = buffImg.getRaster();

      for (int y=0;y<height;y++) {
        for (int x=0;x<width;x++) {

          p = pixels.get((y) * width + (x));
          r = p.getColor().getRed();
          g = p.getColor().getGreen();
          b = p.getColor().getBlue();

          raster.setSample(x, y, 0, r);
          raster.setSample(x, y, 1, g);
          raster.setSample(x, y, 2, b);
        }
      }

      buffImg.copyData(raster);
      ImageIO.write(buffImg, "png", outputfile);

    } catch (IOException e) {

    }
  }

  @Override
  public String toString() {
    return "PNG";
  }
}
