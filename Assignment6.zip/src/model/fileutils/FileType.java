package model.fileutils;

/**
 * Represents a file of various formats. Provides support for reading and writing.
 */
public interface FileType<K> {
  /**
   * Reads the FileType to the K object.
   *
   * @param filename A string representing the filepath
   *
   * @return K object containing the file data.
   */
  K read(String filename);

  /**
   * Writes the K Object to the a file of the class' type.
   *
   * @param toWrite the object to write
   * @param filePath a String representing the file destination.
   *
   * @throws IllegalArgumentException if the file cannot be written.
   */
  void write(K toWrite, String filePath);
}
