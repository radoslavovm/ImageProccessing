package model.fileutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import model.image.Color;
import model.image.ColorImpl;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;

/**
 * Represents an implementation of a .txt file.
 */
public class TXT implements FileType<String> {

  @Override
  public String read(String filename) {
    //create a scanner
    Scanner sc;

    try {
      //try scanning the file
      sc = new Scanner(new FileInputStream(filename));
    }
    catch (FileNotFoundException e) {
      //if we can't throw an exception
      throw new IllegalArgumentException("File " + filename + " not found!");
    }
    //if we can, create a sb
    StringBuilder builder = new StringBuilder();

    //read the file line by line, and populate a string.
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      builder.append(s);
    }

    return builder.toString();
  }

  @Override
  public void write(String toWrite, String filePath) {
    StringBuilder sb = new StringBuilder(toWrite);

    FileOutputStream os = null;
    File output;

    try {
      //Specify the file path here
      output = new File(filePath + "layerInfo.txt");
      os = new FileOutputStream(output);

      if (!output.exists()) {
        output.createNewFile();
      }

      byte[] bytesArray = sb.toString().getBytes();

      os.write(bytesArray);
      os.flush();
      System.out.println("File Written Successfully");
    }
    catch (IOException ioe) {
      throw new IllegalArgumentException("File could not be written");
    }
    finally {
      try {
        if (os != null)
        {
          os.close();
        }
      }
      catch (IOException ioe) {
        throw new IllegalArgumentException("Output stream could not be closed");
      }
    }
  }

  @Override
  public String toString() {
    return "TXT";
  }
}
