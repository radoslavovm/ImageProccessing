package model.image;

/**
 * Represents an (x,y) position.
 */
public interface Posn {
  /**
   * Gets the x position of the Posn object.
   *
   * @return the x position of the Posn object
   */
  int getXPos();

  /**
   * Gets the y position of the Posn object.
   *
   * @return the y position of the Posn object
   */
  int getYPos();
}
