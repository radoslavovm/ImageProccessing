package model.image;

public class PixelImpl implements Pixel {
  private Color color;
  private Posn posn;

  public PixelImpl(Color color, Posn posn) {
    this.color = color;
    this.posn = posn;
  }

  @Override
  public Color getColor() {
    //Martina
    return new ColorImpl(this.color.getRed(), this.color.getBlue(), this.color.getGreen());
  }

  @Override
  public Posn getPosn() {
    return new PosnImpl(this.posn.getXPos(), this.posn.getYPos());
  }
}
