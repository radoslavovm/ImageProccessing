package view;

import java.io.IOException;

/**
 * Represents the view of a processing model. Contains methods to display the model, render messages
 * to the model, and a toString method.
 */
public interface ProcessingView {
  /**
   * Converts the model to a string representation. Implementation is up to inheriting class.f
   *
   * @return a string representation of the model
   */
  String toString();

  /**
   * Renders the object to the destination provided.
   *
   * @throws java.io.IOException if the transmission fails.
   */
  void renderModel() throws IOException;

  /**
   * Renders a message to the destination provided.
   *
   * @param toRender the string message to render
   *
   * @throws IOException if the transmission fails.
   */
  void renderMessage(String toRender) throws IOException;
}
