import model.image.Posn;
import model.image.PosnImpl;
import org.junit.Test;

/**
 * Tests the posn implementation class.
 */
public class TestPosnImpl {
  Posn p1;
  Posn p2;
  Posn p3;

  /**
   * Initializes the data for the tests.
   */
  public void initData() {
    p1 = new PosnImpl(3,4);
    p2 = new PosnImpl(4, 2);
    p3 = new PosnImpl(100, 76);
  }

  //Tests an IAE is thrown with a negative x
  @Test(expected = IllegalArgumentException.class)
  public void testNegXIAE_Constructor_PosnImpl() {
    initData();
    Posn p4 = new PosnImpl(-1, 34234);
  }

  //Tests an IAE is thrown with a negative y
  @Test(expected = IllegalArgumentException.class)
  public void testNegYIAE_Constructor_PosnImpl() {
    initData();
    Posn p4 = new PosnImpl(1, -34234);
  }
}
