import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import model.filters.FilterCommand;
import model.filters.Sepia;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import org.junit.Test;

/**
 * Test class for the Sepia filter class.
 */
public class TestSepia {
  FilterCommand sepia;
  ArrayList<Pixel> pixels;
  Image test;

  /**
   * Initializes data for the grayscale tests.
   */
  public void initData() {
    sepia = new Sepia();
    pixels = new ArrayList<Pixel>();
    for (int i = 0; i < 100; i++) {
      pixels.add(new PixelImpl(new ColorImpl(3, 123, 234), new PosnImpl(0, 0)));
    }
    test = new ImageImpl("pixels", pixels, 10, 10);
  }

  //tests that an IAE is thrown when the image is null
  @Test(expected = IllegalArgumentException.class)
  public void testIAEImageNull_GrayScale() {
    sepia.apply(null);
  }

  //tests that all pixel values in the resultant image are sepia'd
  @Test
  public void testAllPixelValuesGray_GrayScale() {
    initData();
    for (Pixel pixel : sepia.apply(test).getPixels()) {
      assertEquals(139, pixel.getColor().getRed());
      assertEquals(124, pixel.getColor().getGreen());
      assertEquals(97, pixel.getColor().getBlue());
    }
  }
}
