import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import model.image.ColorImpl;
import model.image.Image;
import model.image.Pixel;
import model.programmatics.CheckerBoard;
import model.programmatics.Programmatic;
import org.junit.Test;

/**
 * Tests class for the CheckerBoard programmatic.
 */
public class TestCheckerBoard {
  Programmatic cb1;
  Programmatic cb2;
  Programmatic cb3;

  /**
   * Initializes data for use in tests.
   */
  public void initData() {
    cb1 = new CheckerBoard(10, 10, new ColorImpl(0, 0, 0), new ColorImpl(255, 255, 255));
    cb2 = new CheckerBoard(1, 100, new ColorImpl(122, 122, 122), new ColorImpl(0,0,0));
    cb3 = new CheckerBoard(5, 10, new ColorImpl(22, 255, 132), new ColorImpl(0,0,0));
  }

  //tests the IAE in the checkerboard constructor
  @Test(expected = IllegalArgumentException.class)
  public void testIAECheckerConstructor_CheckerBoard() {
    Programmatic cb4 = new CheckerBoard(1, 9,new ColorImpl(0,0,0), new ColorImpl(0,0,0));
  }

  //tests that an IAE is thrown if the size of the image to be made doesn't match the num of pixels
  //in the board
  @Test(expected = IllegalArgumentException.class)
  public void testIAECheckerBoard_Generate() {
    initData();
    cb1.generate(1,1);
  }

  //tests that an actual checkerboard is generated
  @Test
  public void testOutputVeracity_Generate() {
    initData();
    int count = 0;
    Image resultant = cb2.generate(100,1);
    for (int i = 0; i < resultant.getPixels().size() - 1; i++) {
      if (count % 2 == 0) {
        assertEquals(0,resultant.getPixels().get(i).getColor().getRed());
      }
      else {
        assertEquals(122, resultant.getPixels().get(i).getColor().getRed());
      }
      count++;
    }
  }
}
