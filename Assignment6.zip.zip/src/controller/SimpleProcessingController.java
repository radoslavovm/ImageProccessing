package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.fileutils.FileType;
import model.image.Image;
import view.ProcessingView;
import view.SimpleProcessingTextView;

public class SimpleProcessingController<K> implements ProcessingController {
  ProcessingModel model;
  ProcessingView view;
  Readable readable;


  /**
   * Constructs a SimpleProcessingController given a model, readable, and appendable.
   *
   * @param model the model to control
   * @param readable the script/interactive file to use
   * @param appendable the appendable to construct the view with
   * @throws IllegalArgumentException if any parameter is null
   */
  public SimpleProcessingController(ProcessingModel model, Readable readable, Appendable appendable) {
    if (model == null || readable == null || appendable == null) {
      throw new IllegalArgumentException("Null parameter to controller");
    }
    this.model = model;
    this.readable = readable;
    this.view = new SimpleProcessingTextView(this.model, appendable);
  }

  @Override
  public void load(FileType<Image> fileType, String filename) {
    this.model.load(fileType, filename);
  }

  @Override
  public void save(int fileTypeIndex, String filePath) {
    this.model.save(fileTypeIndex, filePath);
  }

  @Override
  public void run() {
    /**
     * create -
     *        ---> layer
     *        ---> programmatic ---> checkerboard ---> int rep width ---> int rep height
     *
     *
     * remove -
     *        ---> integer index representing layer to delete
     *
     * current -
     *         ---> (integer representing 1 based index)
     *
     * visibility -
     *         ---> (integer representing 1 based index)
     *
     * load -
     *      ---> image ---> integer representing resultant index
     *      ---> file ---> int representing fileType --> string representing filePath
     *
     * save -
     *      ---> fileType index ---> destination path ---> current
     *                                                ---> all
     *
     * filter -
     *        ---> int index of the image to filter --> index of filter to use
     *
     * # -
     *   ---> ignore the rest of the line
     *
     */
    this.tryRenderModel();
    Scanner sc = new Scanner(this.readable);

    int argCount = 0;

    while (sc.hasNext()) {
      switch (argCount) {
        case 0: argCount = this.scanHighLevelCmds(sc);
          break;
        case 1: if (this.scanCreateCmds(sc)) {
                  argCount = 0;
                }
          break;
        case 2: this.scanCurrentCmds(sc);
                argCount = 0;

        //scanning parameters to current
          break;
        case 3: this.scanLoadCmds(sc);
                argCount = 0;

        //scanning parameters to load
          break;
        case 4: this.scanSaveCmds(sc);
                argCount = 0;
        //scanning parameters to save
          break;
        case 5: this.scanFilterCmds(sc);
                argCount = 0;
        //scanning parameters to filter
          break;
        case 6: this.scanRemove(sc);
                argCount = 0;
          break;
        case 7: this.scanChangeVisibility(sc);
                argCount = 0;
          break;
        case 8: sc.nextLine();
          argCount = 0;
          //ignore the rest of the line
          break;
        default:
          throw new IllegalArgumentException("Failed to parse command");
      }
      this.tryRenderModel();
    }
  }

  /**
   * Scans for the high level commands, returns the integer of the corresponding command.
   *
   * @param sc the scanner to parse
   * @return an integer representing which argument to move on to next
   */
  private int scanHighLevelCmds(Scanner sc) {
    String cmd = sc.next();
    int resultant = 0;
    switch (cmd) {
      case "create": resultant = 1;
        break;
      case "current": resultant = 2;
        break;
      case "load": resultant = 3;
        break;
      case "save": resultant = 4;
        break;
      case "filter": resultant = 5;
        break;
      case "remove": resultant = 6;
        break;
      case "visibility":
        resultant = 7;
        break;
      case "#": resultant = 8;
        break;
      default:
        this.tryRenderMessage("Please input a valid starting command. (create, current, load, save, filter, #)");
        break;
    }
    return resultant;
  }

  private void scanFilterCmds(Scanner sc) {
    int filterInd;
    int count = 0;
    try {
      int toFilter = sc.nextInt();
      count++;
      filterInd = sc.nextInt();
      this.model.applyFilter(toFilter, filterInd);
    }
    catch (InputMismatchException e) {
      if (count == 0) {
        this.tryRenderMessage("Please reinput a valid image index in a new command");
        return;
      }
      else if (count == 1) {
        this.tryRenderMessage("Please reinput a valid filter index in a new command");
        return;
      }
      else {
        return;
      }
    }
    catch (NoSuchElementException e) {
      this.tryRenderMessage("Scanner has run out of input");
      return;
    }
    catch (IllegalArgumentException e) {
      this.tryRenderMessage("Filter failed, please try again");
      return;
    }
  }

  private void scanSaveCmds(Scanner sc) {
    int fileIndex = 0;
    String pathToSave = "";
    try {
      fileIndex = sc.nextInt();
      pathToSave = sc.next();
    }
    catch (InputMismatchException e) {
      this.tryRenderMessage("Please input a valid card index");
    }
    catch (NoSuchElementException e) {
      this.tryRenderMessage("Scanner ran out of input to parse");
      return;
    }

    try {
      String cmd = sc.next();
      if (cmd.equals("all")) {
        try {
          this.model.saveAll(fileIndex, pathToSave);
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("invalid save, please re-input command");

        }
      }
      else if (cmd.equals("current")) {
        try {
          this.model.save(fileIndex, pathToSave);
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("invalid save, please re-input command");
        }
      }
      else {
        this.tryRenderMessage("Input valid command\n");
      }
    }
    catch (NoSuchElementException e) {
      return;
    }
  }

  private void scanRemove(Scanner sc) {
    try {
      int layerIndex = sc.nextInt();
      this.model.removeLayer(layerIndex);
    }
    catch (InputMismatchException e) {
      this.tryRenderMessage("Please input a valid index to remove in a valid command\n");
    }
    catch (NoSuchElementException e) {
      this.tryRenderMessage("Scanner is out of input\n");
      return;
    }
    catch (IllegalArgumentException e) {
      this.tryRenderMessage("Add valid layer index to remove\n");
      return;
    }
  }

  /**
   * Scans until a valid command can be read for create. If no valid command can be executed, returns false.
   * If a valid command is parsed, it will be executed.
   * @param sc
   * @return true if a command has been executed, false if not
   *
   * @throws IllegalArgumentException if the scanner doesn't have enough inputs to fill the cmd
   */
  private boolean scanCreateCmds(Scanner sc) {
    String cmd = sc.next();

    boolean executed = false;
    if (cmd.equals("layer")) {
      try{
        this.model.addLayer();
        executed = true;
      }
      catch (IllegalArgumentException e) {
        this.tryRenderMessage("Please load an image before creating a layer");
      }
    }
    else if (cmd.equals("programmatic")) {
      try {
        String progType = sc.next();
        try {
          this.executeGeneration(progType, sc);
          executed = true;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("invalid generation, try again");
        }
      }
      catch (InputMismatchException e) {
        this.tryRenderMessage("Please input a valid layer index");
      }
      catch (NoSuchElementException e) {
        return false;
      }
    }
    else {
      this.tryRenderMessage("Please input a valid create subcommand (layer, programmatic)");
    }
    return executed;
  }


  private void executeGeneration(String progType, Scanner sc) throws IllegalArgumentException {
    int count = 0;
    int width = -1;
    int height = -1;
    int progIndex = this.model.getProgrammaticIndexOf(progType);
    if (progIndex == -1) {
      this.tryRenderMessage("Please input a valid programmatic");
      return;
    }
    else {
      count++;
    }
    try {
      width = sc.nextInt();
      count++;
      height = sc.nextInt();
      count++;
      this.model.generate(width,height,progIndex);
    }
    catch (InputMismatchException e) {
      if (count == 1) {
        this.tryRenderMessage("Please input a valid width in a new command");

        return;
      }
      else if (count == 2) {
        this.tryRenderMessage("Please input a valid height in a new command");

        return;
      }
      else {
        this.tryRenderMessage("count = 3 execute");
        return;
      }
    }
    catch (NoSuchElementException e) {
      this.tryRenderMessage("ran out of input");
      return;
    }
    catch (IllegalArgumentException e) {
      this.tryRenderMessage("Generation failed, try again");
    }

  }

  private void tryFailedExecuteGeneration(Scanner sc, String progType, int count, int width, int height) {
    int progIndex = this.model.getProgrammaticIndexOf(progType);
    switch (count) {
      case 0: this.executeGeneration(progType, sc);
        break;
      case 1: try {
        width = sc.nextInt();
        count++;
        height = sc.nextInt();
        count++;
      }
      catch (InputMismatchException e) {
        if (count == 1) {
          this.tryRenderMessage("Please input a valid width");
          this.tryFailedExecuteGeneration(sc, progType, count, width, height);
          return;
        }
        else if (count == 2) {
          this.tryRenderMessage("Please input a valid height");
          this.tryFailedExecuteGeneration(sc, progType, count, width, height);
          return;
        }
        else {
          throw new IllegalArgumentException("Scanner cannot be parsed");
        }
      }
      catch (NoSuchElementException e) {
        throw new IllegalArgumentException("Scanner has no more input:/");
      }
      break;
      case 2: try {
        height = sc.nextInt();
        count++;
      }
      catch (InputMismatchException e) {
        this.tryRenderMessage("Please input a valid height");
        this.tryFailedExecuteGeneration(sc, progType, count, width, height);
        return;
      }
      catch (NoSuchElementException e) {
        throw new IllegalArgumentException("Scanner has no more input:/");
      }
        break;
      default: throw new IllegalArgumentException("Scanner cannot be parsed");
    }
    this.model.generate(width, height, progIndex);
  }

  private boolean scanCurrentCmds(Scanner sc) {
    int index = -1;
    boolean executed = false;
    try {
      index = sc.nextInt();
      this.model.setTopmost(index);
      executed = true;
    }
    catch (InputMismatchException e) {
      this.tryRenderMessage("Please input a valid index in a new command");
      return false;
    }
    catch (NoSuchElementException e) {
      return false;
    }
    catch (IllegalArgumentException e) {
      this.tryRenderMessage("Invalid selection, please try again");
    }
    return executed;
  }

  private void tryRenderMessage(String message) {
    try {
      this.view.renderMessage(message);
    }
    catch (IOException e) {
      throw new IllegalArgumentException("Cannot write to appendable");
    }
  }

  private boolean scanLoadCmds(Scanner sc) {
    String type = sc.next();
    int count = 0;
    boolean executed = false;
    switch (type) {
      case "image":
        try {
          count = 1;
          int toLoad = sc.nextInt();
          this.model.loadImage(this.model.getResultantImageAt(toLoad));
          executed = true;
        }
        catch (InputMismatchException e) {
          this.tryRenderMessage("Please input a valid index of the image to load in a new command\n");
          return true;
        }
        catch (NoSuchElementException e) {
          return false;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("Please input a valid index of the image to load in a new command\n");
          return true;
        }
        break;
      case "file":
        try {
          count = 2;
          int fileType = sc.nextInt();
          count = 3;
          String toLoad = sc.next();
          this.model.load(this.model.getFileTypeAt(fileType), toLoad);
        }
        catch (InputMismatchException e) {
          this.tryRenderMessage("Please input a valid fileType index in a new command\n");
          return true;
        }
        catch (NoSuchElementException e) {
          return false;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("Load failed\n");
          return true;
        }
        break;
      default: this.tryRenderMessage("Please input a valid subcommand (image, file)\n");
        break;
    }
    return false;
  }

  private void tryFailedLoad(Scanner sc, int count) {
    switch (count) {
      case 1:
        try {
          int toLoad = sc.nextInt();
          this.model.loadImage(this.model.getResultantImageAt(toLoad));
        }
        catch (InputMismatchException e) {
          this.tryRenderMessage("Please input a valid index of the image to load");
          this.tryFailedLoad(sc, count);
          return;
        }
        catch (NoSuchElementException e) {
          this.tryRenderMessage("Scanner ran out of input");
          return;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("Load failed");
          return;
        }
        break;
      case 2:
        try {
          int fileType = sc.nextInt();
          count = 3;
          String filePath = sc.next();
          this.model.load(this.model.getFileTypeAt(fileType), filePath);
        }
        catch (InputMismatchException e) {
          this.tryRenderMessage("Please input a valid index of the image to load");
          this.tryFailedLoad(sc, count);
        }
        catch (NoSuchElementException e) {
          this.tryRenderMessage("Scanner ran out of input");
          return;
        }
        catch (IllegalArgumentException e) {
          this.tryRenderMessage("Load failed");
          return;
        }
        break;
      default: return;
    }
  }

  private void scanChangeVisibility(Scanner sc) {
    try {
      int toChange = sc.nextInt();
      this.model.changeVisibilityOf(toChange);
    }
    catch (InputMismatchException e) {
      this.tryRenderMessage("Please input a valid index to change");
      return;
    }
    catch (NoSuchElementException e) {
      this.tryRenderMessage("Scanner ran out of input");
      return;
    }
    catch (IllegalArgumentException e) {
      this.tryRenderMessage("Load failed due to invalid index, please try again");
    }
  }

  private void tryRenderModel() {
    try {
      this.view.renderModel();
    }
    catch (IOException e) {
      throw new IllegalArgumentException("Cannot write to appendable");
    }
  }
}
