package view;

import controller.ProcessingController;
import java.io.IOException;
import model.ProcessingModel;

public class SimpleProcessingTextView implements ProcessingView {
  private final ProcessingModel model;
  private Appendable appendable;
  

  /**
   * Constructs this object given a model and an appendable.
   * @throws IllegalArgumentException if the appendable is null
   */
  public SimpleProcessingTextView(ProcessingModel model, Appendable appendable) {
    if (appendable == null) {
      throw new IllegalArgumentException("null appendable");
    }
    this.model = model;
    this.appendable = appendable;
  }

  @Override
  public String toString() {
    return this.model.toString();
  }

  @Override
  public void renderModel() throws IOException {
    try {
      String model = this.toString();
      this.appendable.append(model);
    }
    catch (IOException e) {
      throw new IOException("Transmission failed");
    }
  }

  @Override
  public void renderMessage(String toRender) throws IOException {
    try {
      this.appendable.append(toRender);
    }
    catch (Exception e) {
      throw new IOException("Transmission failed");
    }
  }
}
