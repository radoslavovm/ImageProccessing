package model.image;

/**
 * Represents a color with various implementations.
 */
public interface Color {
  /**
   * Clamps the given integer to a 0-255 range.
   *
   * @param toClamp the int to be clamped
   */
  static int clamp(int toClamp) {
    if (toClamp < 0) {
      return 0;
    }
    else if (toClamp > 255) {
      return 255;
    }
    else {
      return toClamp;
    }
  }

  /**
   * Gets the red value of the Color object.
   *
   * @return an int representing a the red value of the pixel
   */
  int getRed();

  /**
   * Gets the green value of the Color object.
   *
   * @return an int representing a the green value of the pixel
   */
  int getGreen();

  /**
   * Gets the blue value of the Color object.
   *
   * @return an int representing a the blue value of the pixel
   */
  int getBlue();

}
