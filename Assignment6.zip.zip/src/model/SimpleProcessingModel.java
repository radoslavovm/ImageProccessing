package model;

import java.util.ArrayList;
import model.fileutils.FileType;
import model.fileutils.TXT;
import model.filters.FilterCommand;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import model.programmatics.Programmatic;

public class SimpleProcessingModel implements ProcessingModel {
  private ArrayList<Image> layers;
  private ArrayList<Integer> layerVisibilities;
  //a layer is visible if the integer is 1, invisible if 0, topmost if 2
  private ArrayList<Image> resultants;
  private ArrayList<Programmatic> programmatics;
  private ArrayList<FilterCommand> filters;
  private ArrayList<FileType<Image>> suppImgTypes;
  private ArrayList<FileType<String>> suppTxtTypes;

  /**
   * Constructs a SimpleProcessingModel.
   *
   * @param image the image to process, defaults to null until loaded.
   * @param programmatics an arraylist of programmatics to support
   * @param filters an arraylist of filters to support
   *
   *
   */
  public SimpleProcessingModel(Image image, ArrayList<Programmatic> programmatics, ArrayList<FilterCommand> filters, ArrayList<FileType<Image>> suppImgTypes) {
    this.layers = new ArrayList<Image>();
    this.layers.add(image);
    this.layerVisibilities = new ArrayList<Integer>();
    for (Image img : this.layers) {
      this.layerVisibilities.add(1);
    }
    this.layerVisibilities.set(0,2);

    this.resultants = new ArrayList<Image>();
    this.programmatics = programmatics;
    this.filters = filters;
    this.suppImgTypes = suppImgTypes;
    this.suppTxtTypes = new ArrayList<FileType<String>>();
  }

  @Override
  public void applyFilter(int imageIndex, int filterIndex) {
    resultants.add(this.getFilterAt(filterIndex).apply(this.getImageAt(imageIndex)));
  }

  @Override
  public void applyTo(int imageIndex, int filterIndex) {
    this.layers.set(imageIndex, this.getFilterAt(filterIndex).apply(this.getImageAt(imageIndex)));
  }

  @Override
  public void generate(int width, int height, int toGen) {
    this.resultants.add(this.getProgrammaticAt(toGen).generate(width, height));
  }

  @Override
  public void load(FileType<Image> fileType, String filename) {
    this.layers.add(fileType.read(filename));
    this.layerVisibilities.add(1);
  }

  @Override
  public void loadImage(Image image) {
    this.layers.add(image);
    this.layerVisibilities.add(1);
  }

  @Override
  public void save(int fileTypeIndex, String filePath) {
    for (int i = 0; i < this.getSizeLayers(); i++) {
      if (this.layerVisibilities.get(i) == 2) {
        this.suppImgTypes.get(fileTypeIndex).write(this.layers.get(i), filePath);
      }
    }
  }

  @Override
  public void saveAll(int fileTypeIndex, String filePath) {
    for (Image image : this.resultants) {
      this.suppImgTypes.get(fileTypeIndex).write(image, filePath);
    }
    this.resultants = new ArrayList<Image>();
    StringBuilder toWrite = new StringBuilder();
    int count = 0;
    for (Image layer : this.layers) {
      this.suppImgTypes.get(fileTypeIndex).write(layer, filePath);
      String layToWrite = "Layer " + count + ": " + layer.getTitle() +"\n";
      toWrite.append(layToWrite);
      count++;
    }
    FileType<String> txt = new TXT();
    txt.write(toWrite.toString(), filePath);
  }

  @Override
  public void addLayer() {
    if (this.getSizeLayers() == 0) {
      throw new IllegalArgumentException("Cannot add a layer to a non-existant image");
    }
    ArrayList<Pixel> toAdd = new ArrayList<Pixel>();
    for (int y = 0; y < this.getImageAt(0).getHeight(); y++) {
      for (int x = 0; x < this.getImageAt(0).getWidth(); x++) {
        toAdd.add(new PixelImpl(new ColorImpl(0,0,0), new PosnImpl(x,y)));
      }
    }
    this.layers.add(new ImageImpl("layer" + this.getSizeLayers(), toAdd, this.getImageAt(0).getWidth(), this.getImageAt(0).getHeight()));
    this.layerVisibilities.add(1);
  }

  @Override
  public void removeLayer(int index) {
    if (this.checkBounds(index, this.layers)) {
      this.layers.remove(index);
      this.layerVisibilities.remove(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public int getNumProgrammatics() {
    return programmatics.size();
  }

  @Override
  public int getNumFilterCommands() {
    return filters.size();
  }

  @Override
  public int getSizeOfResultants() {
    return this.resultants.size();
  }

  @Override
  public int getSizeLayers() {
    return this.layers.size();
  }

  @Override
  public Programmatic getProgrammaticAt(int index) {
    if (this.checkBounds(index, this.programmatics)) {
      return this.programmatics.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public FilterCommand getFilterAt(int index) {
    if (this.checkBounds(index, this.filters)) {
      return this.filters.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public Image getImageAt(int index) {
    if (this.checkBounds(index, this.layers)) {
      return this.layers.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public Image getResultantImageAt(int index) {
    if (this.checkBounds(index, this.resultants)) {
      return this.resultants.get(index);
    }
    else {
      throw new IllegalArgumentException("Invalid index");
    }
  }

  @Override
  public int getProgrammaticIndexOf(String title) {
    int count = 0;
    for (Programmatic gen : this.programmatics) {
      if (title == gen.toString().toLowerCase()) {
        return count;
      }
      count++;
    }
    return count;
  }

  @Override
  public void setTopmost(int index) {
    if (checkBounds(index, this.layerVisibilities)) {
      for (int i = 0; i < this.layerVisibilities.size(); i++) {
        if (this.layerVisibilities.get(i) == 2) {
          this.layerVisibilities.set(i, 1);
        }
        else {
          //do nothing
        }
      }
      this.layerVisibilities.set(index, 2);
    }
    else {
      throw new IllegalArgumentException("Index out of bounds");
    }
  }

  @Override
  public void changeVisibilityOf(int index) {
    if (this.checkBounds(index, this.layerVisibilities)) {
      if (this.layerVisibilities.get(index) == 0) {
        this.layerVisibilities.set(index, 1);
      }
      else if (this.layerVisibilities.get(index) == 1) {
        this.layerVisibilities.set(index, 0);
      }
      else if (this.layerVisibilities.get(index) == 2) {
        this.layerVisibilities.set(index, 0);
        this.setNewTopmost();
      }
    }
    else {
      throw new IllegalArgumentException("Index OOB");
    }
  }

  /**
   * Sets the topmost visible layer as the topmost layer.
   */
  private void setNewTopmost() {
    for (Integer inte : this.layerVisibilities) {
      if (inte == 1) {
        this.setTopmost(inte);
        break;
      }
    }
  }

  @Override
  public FileType<Image> getFileTypeAt(int index) {
    return this.suppImgTypes.get(index);
  }

  /**
   * Checks the if the index is valid given the list.
   *
   * @param index the index to check
   * @param list the list to check against
   *
   * @return true if the index is inbounds, false if not.
   */
  private boolean checkBounds(int index, ArrayList list) throws IllegalArgumentException {
    return index < list.size() && index >= 0;
  }

  @Override
  public int getCurrentIndex() {
    for (int i = 0; i < this.getSizeLayers(); i++) {
      if (this.layerVisibilities.get(i) == 2) {
        return i;
      }
    }
    return -1;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("Layers:\n");
    int count = 0;
    for (Image image : this.layers) {
      if (image == null) {
        builder.append("");
      }
      else {
        String dimensions = " -- " + image.getWidth() + " x " + image.getHeight();
        String visibility;
        if (count > layerVisibilities.size()) {
          continue;
        }
        else {
          if (this.layerVisibilities.get(count) == 0) {
            visibility = " -- invisible";
          }
          else if (this.layerVisibilities.get(count) == 1){
            visibility = " -- visible";
          }
          else if (this.layerVisibilities.get(count) == 2) {
            visibility = " -- current";
          }
          else {
            visibility = "";
          }
          String curLayer = "Layer " + count + " -- " + this.getImageAt(count).getTitle() + visibility + dimensions + "\n";
          builder.append(curLayer);
          count++;
        }
      }
    }
    builder.append("Resultants:\n");
    for (int i = 0; i < this.resultants.size(); i++) {
      String curResultant = this.getResultantImageAt(i).getTitle() + "\n";
      builder.append(curResultant);
    }
    builder.append("Supported Programmatics:\n");
    for (int i = 0; i < this.programmatics.size(); i++) {
      String curProgrammatic = this.getProgrammaticAt(i).toString() + "\n";
      builder.append(curProgrammatic);
    }
    builder.append("Supported Filters:\n");
    for (int i = 0; i < this.filters.size(); i++) {
      String curFilter = this.getFilterAt(i).toString() + "\n";
      builder.append(curFilter);
    }
    builder.append("Supported Image Output FileTypes: \n");
    for (int i = 0; i < this.suppImgTypes.size(); i++) {
      String curImgType = this.suppImgTypes.get(i).toString() + "\n";
      builder.append(curImgType);
    }
    builder.append("Supported Text Output FileTypes: \n");
    for (int i = 0; i < this.suppTxtTypes.size(); i++) {
      String curTxtType = this.suppTxtTypes.get(i).toString() + "\n";
      builder.append(curTxtType);
    }

    return builder.toString();
  }
}
