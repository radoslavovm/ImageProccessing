import controller.ProcessingController;
import controller.SimpleProcessingController;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.fileutils.FileType;
import model.fileutils.JPEG;
import model.fileutils.PNG;
import model.fileutils.PPM;
import model.filters.FilterCommand;
import model.filters.GaussianBlur;
import model.filters.Grayscale;
import model.filters.Sepia;
import model.filters.Sharpen;
import model.image.ColorImpl;
import model.image.Image;
import model.programmatics.CheckerBoard;
import model.programmatics.Programmatic;
import view.ProcessingView;
import view.SimpleProcessingTextView;

public class main {
  //demo main
  public static void main(String []args) {

    FileType<Image> ppm = new PPM();
    FileType<Image> jpeg = new JPEG();
    FileType<Image> png = new PNG();

    FilterCommand gray = new Grayscale();
    FilterCommand sepia = new Sepia();
    FilterCommand gaussianBlur = new GaussianBlur();
    FilterCommand sharpen = new Sharpen();

    Programmatic checker = new CheckerBoard(10, 10, new ColorImpl(0, 0, 0), new ColorImpl(255,255,255));

    ProcessingModel spm = new SimpleProcessingModel(null, new ArrayList<Programmatic>(
        Arrays.asList(checker)), new ArrayList<FilterCommand>(Arrays.asList(gray,sepia,gaussianBlur,sharpen)), new ArrayList<FileType<Image>>(Arrays.asList(ppm, jpeg, png)));
    ProcessingController spc = new SimpleProcessingController<Image>(spm, new InputStreamReader(System.in), System.out);
    ProcessingView spv = new SimpleProcessingTextView(spm, System.out);
    spc.load(ppm, "./res/blackbuck.ascii.ppm");
    spm.removeLayer(0);
    spc.run();
  }
}
