package model.image;

/**
 * An RGB implementation of the Color interface. Objects of this class have a red, green, and blue
 * value represented as integers. No field of this class can be greater than 255 or less than 0.
 */
public class ColorImpl implements Color {
  private int r;
  private int g;
  private int b;

  /**
   * Constructs a Color object with a red, green and blue channel.
   * @param r
   * @param g
   * @param b
   */
  public ColorImpl(int r, int g, int b) {
    this.r = Color.clamp(r);
    this.g = Color.clamp(g);
    this.b = Color.clamp(b);
  }

  @Override
  public int getRed() {
    return this.r;
  }

  @Override
  public int getGreen() {
    return this.g;
  }

  @Override
  public int getBlue() {
    return this.b;
  }

  @Override
  public void setRed(int r) {
    this.r = Color.clamp(r);
  }

  @Override
  public void setGreen(int g) {
    this.g = Color.clamp(g);
  }

  @Override
  public void setBlue(int b) {
    this.b = Color.clamp(b);
  }
}
