package model;

import model.fileUtils.FileType;
import model.filters.FilterCommand;
import model.image.Image;
import model.image.ImageImpl;
import model.programmatics.Programmatic;

public class SimpleProcessingModel implements ProcessingModel {

  @Override
  public Image applyFilter(Image image, FilterCommand filter) {
    return filter.apply(image);
  }

  @Override
  public Image generate(int width, int height, Programmatic toGen) {
    return new ImageImpl(toGen.generate(width, height), width, height);
  }

  @Override
  public Image load(FileType<Image> fileType, String filename) {
    return fileType.read(filename);
  }

  @Override
  public void save(FileType<Image> fileType, Image image) {
    fileType.write(image);
  }
}
