package model.programmatics;

import java.util.ArrayList;
import model.image.Color;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.Posn;
import model.image.PosnImpl;

public class CheckerBoard implements Programmatic {

  private final int sizePerSq;
  private final int numSquares;
  private final Color lightCol;
  private final Color darkCol;

  public CheckerBoard(int sizePerSq, int numSquares, Color lightCol, Color darkCol) {
    this.sizePerSq = sizePerSq;
    this.numSquares = numSquares;
    this.lightCol = lightCol;
    this.darkCol = darkCol;
  }

  @Override
  public ArrayList<Pixel> generate(int width, int height) {
    ArrayList<Pixel> resultant = new ArrayList<Pixel>();

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {

      }
    }
    return resultant;
  }


}
