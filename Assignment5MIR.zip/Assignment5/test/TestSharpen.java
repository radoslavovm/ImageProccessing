import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import model.SimpleProcessingModel;
import model.filters.BoxBlur;
import model.filters.FilterCommand;
import model.filters.Sharpen;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import org.junit.Test;

public class TestSharpen {

  //Original
  Pixel p1 = new PixelImpl(new ColorImpl(32, 32, 32), new PosnImpl(0,0));
  Pixel p2 = new PixelImpl(new ColorImpl(16, 32, 64), new PosnImpl(1,0));
  Pixel p3 = new PixelImpl(new ColorImpl(64, 96, 16), new PosnImpl(2,0));
  Pixel p4 = new PixelImpl(new ColorImpl(16, 16, 16), new PosnImpl(3,0));
  Pixel p5 = new PixelImpl(new ColorImpl(32, 0, 32), new PosnImpl(0,1));
  Pixel p6 = new PixelImpl(new ColorImpl(32, 32, 96), new PosnImpl(1,1));
  Pixel p7 = new PixelImpl(new ColorImpl(0, 32, 32), new PosnImpl(2,1));
  Pixel p8 = new PixelImpl(new ColorImpl(32, 32, 0), new PosnImpl(3,1));
  Pixel p9 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(0,2));
  Pixel p10 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(1,2));
  Pixel p11 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(2,2));
  Pixel p12 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(3,2));

  //Blurred
  Pixel p01 = new PixelImpl(new ColorImpl(32, 32, 32), new PosnImpl(0,0));
  Pixel p02 = new PixelImpl(new ColorImpl(16, 32, 64), new PosnImpl(1,0));
  Pixel p03 = new PixelImpl(new ColorImpl(64, 96, 16), new PosnImpl(2,0));
  Pixel p04 = new PixelImpl(new ColorImpl(16, 16, 16), new PosnImpl(3,0));
  Pixel p05 = new PixelImpl(new ColorImpl(32, 0, 32), new PosnImpl(0,1));
  Pixel p06 = new PixelImpl(new ColorImpl(32, 32, 96), new PosnImpl(1,1));
  Pixel p07 = new PixelImpl(new ColorImpl(0, 32, 32), new PosnImpl(2,1));
  Pixel p08 = new PixelImpl(new ColorImpl(32, 32, 0), new PosnImpl(3,1));
  Pixel p09 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(0,2));
  Pixel p010 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(1,2));
  Pixel p011 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(2,2));
  Pixel p012 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(3,2));

  @Test
  public void testCorrectSharpen() {

    ArrayList<Pixel> p = new ArrayList<>();
    p.add(0, p1);
    p.add(1, p2);
    p.add(2, p3);
    p.add(3, p4);
    p.add(4, p5);
    p.add(5, p6);
    p.add(6, p7);
    p.add(7, p8);
    p.add(8, p9);
    p.add(9, p10);
    p.add(10, p11);
    p.add(11, p12);

    Image img = new ImageImpl(p, 4, 3);

    ArrayList<Pixel> expected = new ArrayList<>();
    expected.add(0, p01);
    expected.add(1, p02);
    expected.add(2, p03);
    expected.add(3, p04);
    expected.add(4, p05);
    expected.add(5, p06);
    expected.add(6, p07);
    expected.add(7, p08);
    expected.add(8, p09);
    expected.add(9, p010);
    expected.add(10, p011);
    expected.add(11, p012);

    Image expect = new ImageImpl(expected, 4, 3);

    SimpleProcessingModel model = new SimpleProcessingModel();
    FilterCommand sharpen = new Sharpen();
    model.applyFilter(img, sharpen);

    assertEquals(expect.toString(), model.applyFilter(img, sharpen).toString());
  }
}
