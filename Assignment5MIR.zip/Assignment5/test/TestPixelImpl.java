public class TestPixelImpl {

}
