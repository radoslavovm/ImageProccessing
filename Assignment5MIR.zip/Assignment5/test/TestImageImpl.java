import java.util.ArrayList;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import org.junit.Test;

public class TestImageImpl {

  //Original
  Pixel p1 = new PixelImpl(new ColorImpl(32, 32, 32), new PosnImpl(0,0));
  Pixel p2 = new PixelImpl(new ColorImpl(16, 32, 64), new PosnImpl(1,0));
  Pixel p3 = new PixelImpl(new ColorImpl(64, 96, 16), new PosnImpl(2,0));
  Pixel p4 = new PixelImpl(new ColorImpl(16, 16, 16), new PosnImpl(3,0));
  Pixel p5 = new PixelImpl(new ColorImpl(32, 0, 32), new PosnImpl(0,1));
  Pixel p6 = new PixelImpl(new ColorImpl(32, 32, 96), new PosnImpl(1,1));
  Pixel p7 = new PixelImpl(new ColorImpl(0, 32, 32), new PosnImpl(2,1));
  Pixel p8 = new PixelImpl(new ColorImpl(32, 32, 0), new PosnImpl(3,1));
  Pixel p9 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(0,2));
  Pixel p10 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(1,2));
  Pixel p11 = new PixelImpl(new ColorImpl(96, 32, 32), new PosnImpl(2,2));
  Pixel p12 = new PixelImpl(new ColorImpl(32, 16, 32), new PosnImpl(3,2));

  @Test (expected = IllegalArgumentException.class)
  public void testWrongWidth()  {
    ArrayList<Pixel> p = new ArrayList<>();
    p.add(0, p1);
    p.add(1, p2);
    p.add(2, p3);
    p.add(3, p4);
    p.add(4, p5);
    p.add(5, p6);
    p.add(6, p7);
    p.add(7, p8);
    p.add(8, p9);
    p.add(9, p10);
    p.add(10, p11);
    p.add(11, p12);
    Image img = new ImageImpl(p, 40, 3);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testWrongHeight()  {
    ArrayList<Pixel> p = new ArrayList<>();
    p.add(0, p1);
    p.add(1, p2);
    p.add(2, p3);
    p.add(3, p4);
    p.add(4, p5);
    p.add(5, p6);
    p.add(6, p7);
    p.add(7, p8);
    p.add(8, p9);
    p.add(9, p10);
    p.add(10, p11);
    p.add(11, p12);
    Image img = new ImageImpl(p, 4, 30);
  }

  @Test
  public void testImg()  {
    ArrayList<Pixel> p = new ArrayList<>();
    p.add(0, p1);
    p.add(1, p2);
    p.add(2, p3);
    p.add(3, p4);
    p.add(4, p5);
    p.add(5, p6);
    p.add(6, p7);
    p.add(7, p8);
    p.add(8, p9);
    p.add(9, p10);
    p.add(10, p11);
    p.add(11, p12);
    Image img = new ImageImpl(p, 4, 3);
    // make img for expected?
  }

  @Test
  public void testZeroPixels()  {
    ArrayList<Pixel> p = new ArrayList<>();
    Image img = new ImageImpl(p, 0, 0);
  }

}
