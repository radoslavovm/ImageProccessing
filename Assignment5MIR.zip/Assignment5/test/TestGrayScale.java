public class TestGrayScale {

}
