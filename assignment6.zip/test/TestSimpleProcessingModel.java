import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import model.ProcessingModel;
import model.SimpleProcessingModel;
import model.filters.FilterCommand;
import model.filters.GaussianBlur;
import model.filters.Grayscale;
import model.filters.Sepia;
import model.filters.Sharpen;
import model.image.ColorImpl;
import model.image.Image;
import model.image.ImageImpl;
import model.image.Pixel;
import model.image.PixelImpl;
import model.image.PosnImpl;
import model.programmatics.CheckerBoard;
import model.programmatics.Programmatic;
import org.junit.Test;

/**
 * Tests the simpleProcessingModel class and its methods.
 */
public class TestSimpleProcessingModel {
  ProcessingModel spm;
  ArrayList<Pixel> pixels;
  Image test;
  FilterCommand gs;
  FilterCommand sepia;
  FilterCommand gaussianBlur;
  FilterCommand sharpen;
  Programmatic cb;

  /**
   * Initializes data for the purpose of testing the SimpleProcessingModel.
   */
  public void initData() {
    pixels = new ArrayList<Pixel>();
    for (int i = 0; i < 100; i++) {
      pixels.add(new PixelImpl(new ColorImpl(i, i, i), new PosnImpl(1, 2)));
    }
    test = new ImageImpl("pixels",pixels, 10, 10);
    gs = new Grayscale();
    sepia = new Sepia();
    gaussianBlur = new GaussianBlur();
    sharpen = new Sharpen();
    cb = new CheckerBoard(10, 10, new ColorImpl(0,0,0), new ColorImpl(255,255,255));
    spm = new SimpleProcessingModel(test, new ArrayList<Programmatic>(Arrays.asList(cb)), new ArrayList<FilterCommand>(
        Arrays.asList(gs,sepia,gaussianBlur,sharpen)));
  }

  //tests that the applyfilter method actually adds a resultant image to our list
  @Test
  public void testApplyActuallyAppliesAndAdds_ApplyFilter() {
    initData();
    assertEquals(0, spm.getSizeOfResultants());
    for (int i = 0; i < spm.getNumFilterCommands(); i++) {
      spm.applyFilter(0,0);
      assertEquals(i + 1, spm.getSizeOfResultants());
    }
  }

  //tests that the generate method actually generates an image and adds it to the resultant
  @Test
  public void testGenerateActuallyGeneratesAndAdds_Generate() {
    initData();
    assertEquals(0, spm.getSizeOfResultants());
    spm.generate(20,50,0);
    assertEquals(1, spm.getSizeOfResultants());
  }


}
