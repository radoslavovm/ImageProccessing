import static org.junit.Assert.assertTrue;

import model.fileutils.FileType;
import model.fileutils.JPEG;
import model.image.ColorImpl;
import model.image.Image;
import model.programmatics.CheckerBoard;
import org.junit.Test;

public class TestJPEG {
  FileType<Image> jpg;
  CheckerBoard cb;
  Image img;

  /**
   * Initializes data for the purpose of testing.
   */
  private void initData() {
    jpg = new JPEG();
    cb =
        new CheckerBoard(10, 10,
            new ColorImpl(0, 0, 0),
            new ColorImpl(255, 255, 255));
    img = cb.generate(100,10);
  }

  //tests that the read method produces an image object
  @Test
  public void testRead_JPEG() {
    initData();
    Image resultant = jpg.read("./res/boston.jpg");
    assertTrue(resultant instanceof Image);
  }

  //tests the write method to create an image
  @Test
  public void testWrite_JPEG() {
    initData();
    jpg.write(img);
  }

}
