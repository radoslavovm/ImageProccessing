This README serves to educate about the design of our Image Processing Model.

To begin with, we constructed the Image interface and the ImageImpl class. We thought an Image should be represented as an object with a title, a list of pixels
that represents Image data, a width(in pixels), and a height(in pixels). Given this definition, our Image interface gives us the methods to query those fields, but not
change them. Naturally, we then defined a Pixel interface and its concrete class. We defined a pixel as an object with a color and a position. Similar to Image,
Pixel gives us the methods to query, but not change a Pixel's fields. From there, we defined a Color interface that can be used to represent many color formats, and
a ColorImpl class representing a 3 channel RGB Color. The Color interface has a clamp static method which ensures all values are within channel ranges. Similar to above,
it also provides methods for querying fields, but not changing them. Our Posn interface follows this same pattern. It is worth noting our PosnImpl class maintains that both
the x and y coordinate must be positive.

After constructing the basics of what an Image is, we moved to Filter support. We implemented the Command Pattern for our filters, making a FilterCommand interface with
an apply method and with each separate filter extending it. This allows us to support future filters now without any work. We did the same thing with Programmatics,
a Command Design Pattern where each programmatic has a generate method which auto generates an image when called. Again this allows for future support, now. We followed this 
same pattern for FileTypes as well, with a FileType<K> interface. Each FileType has a read and a write method that converts the file to an object, and exports an object 
as a file respectively. This again allows for future support now.

Now that the building blocks have been laid, we made our ProcessingModel and ProcessingModelState interfaces. ProcessingModel contains the important operations, 
loading an image from a file, loading an image from an image, applying a filter on an image, generating an image, and writing an image out to a file. ProcessingModelState
contains many operations for querying the model's state similar to FreecellModelState. From these interfaces, we created the concrete class SimpleProcessingModel. This class
contains an active Image object; an ArrayList of Images designed to store the results of filters, generations etc; an ArrayList of Programmatic objects which represents
the supported programmatics the model has; and finally, an ArrayList of Filters, similarly representing the supported filters the model has. 

Images are from this site:

blackbuck.ascii.ppm citation:

colors.ascii.ppm citation: